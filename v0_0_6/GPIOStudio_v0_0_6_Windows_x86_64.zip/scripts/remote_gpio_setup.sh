echo "Now installing python remote GPIO Dependencies"
pip3 install gpiozero pigpio